from .rdf_load import *
