# Lambda function `check`

This lambda function is called by the RDF Load Step Function
and checks if a given load instruction has completed.

