rdf_extension_format_map = {
    ".ttl": "turtle",
    ".nt": "ntriples"
}
