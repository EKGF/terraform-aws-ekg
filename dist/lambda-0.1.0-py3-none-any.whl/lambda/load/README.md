# Lambda function `load`

This lambda function is called by the RDF Load Step Function
and instructs the Neptune loader to start loading the given S3 file.

